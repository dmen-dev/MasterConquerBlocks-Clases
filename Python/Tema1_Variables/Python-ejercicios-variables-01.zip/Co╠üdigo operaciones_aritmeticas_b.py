# --- Pedimos un numero por pantalla ---
n = float(input("Introduce un número: "))
operacion = n * (n+1) / 2
print(operacion)