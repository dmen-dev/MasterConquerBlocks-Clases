# --- Pedimos al usuario que introduzca un número
numero = input("Por favor, introduce un número de cuatro cifras ") #string

# --- Mostrar el número componente a componente por pantalla
print(numero[0] + "\n" + numero[1] + "\n" + numero[2] + "\n" + numero[3])
