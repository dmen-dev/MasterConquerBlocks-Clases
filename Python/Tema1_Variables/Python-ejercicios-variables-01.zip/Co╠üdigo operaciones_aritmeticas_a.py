# --- Definimos la operacion ---
operacion = ((3+2)/(2*5))**2
operacion2 = ((3+2) /2 /5) **2
print(operacion)
print(operacion2)