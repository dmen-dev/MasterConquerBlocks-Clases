# --- Pedir un string de cinco caracteres ---
palabra = input("Ingresa una palabra de 5 caracteres: ")

print(palabra[0]+palabra[0]+palabra[1]+palabra[1]+palabra[2]+\
    palabra[2]+palabra[3]+palabra[3]+palabra[4]+palabra[4])
print(palabra[0]*2+palabra[1]*2+palabra[2]*2+\
    palabra[3]*2+palabra[4]*2)